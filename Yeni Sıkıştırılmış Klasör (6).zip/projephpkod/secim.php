<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Secim</title>
    <link rel="stylesheet" href="secim.css">
    <link rel="icon" href="img/logo.jpg" type="image/jpeg">
</head>
<body>
   <div class="menu">
            <ul>
            <li><a href="musteri_ekleme.php">Müşteri Ekleme</a></li>
            <li><a href="musteri_liste.php">Müşteri Liste</a></li>
            <li><a href="siparis_ekle.php">Sipariş Ekle</a></li>
            <li><a href="siparisler.php">Siparişler</a></li>
	    <li><a href="tir_takibi.php">Tır Takibi</a></li>
 	    <li><a href="faturalar.php">Faturalar</a></li>
	    <li><a href="teslimat_rotası.php">Teslimat Rotası</a></li>
            </ul>
   	    </div>
    <div class="image-container">
        <img src="img/lojistik.png" alt="Lojistik Resmi" class="center-image">
    </div>
</body>
</html>
